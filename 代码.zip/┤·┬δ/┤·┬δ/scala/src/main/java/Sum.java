public class Sum {

    public static void main(String[] args) {
//        long n = 100000000;
//        long sum = 0;
//        for (long i = n; i >= 1; i--) {
//            sum += i;
//        }
//        System.out.println(sum);

        int sum = 0;
        for (int i = 2; i <= 10; i++) {
            sum+=i;
        }
        System.out.println(sum); // 6*
    }
}
